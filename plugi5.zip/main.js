// main.js yang sudah diperbaiki
/**
 * @param {object} plugin
 * @param {object} plugin.onInit
 */
function plugin(plugin) {
  plugin.onInit = function() {
    acode.require("panel").open("AI Assistant Panel", "panel.html");
  };

  // Kamu bisa menambahkan fungsi onPause, onResume, onUninstall, dll. di sini jika diperlukan
  // plugin.onUninstall = function() {
  //   acode.showToast('AI Assistant Plugin uninstalled!');
  // };
}
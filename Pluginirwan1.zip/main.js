export default {
  onInit() {
    acode.require("panel").open("AI Assistant Panel", "panel.html");
  }
};
